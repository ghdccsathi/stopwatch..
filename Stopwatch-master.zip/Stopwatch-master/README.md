# Stopwatch
A Simple Android Application Developed in Android Studio in Java

Screenshots:


![Screenshot (10)](https://github.com/SumaitaB/Stopwatch/assets/51522304/ac758dbe-c619-407e-b8a6-e5ea9df988b6)


![Screenshot (11)](https://github.com/SumaitaB/Stopwatch/assets/51522304/fbc9f5f5-968d-46c5-861f-ec62278e4fd9)
![Screenshot (9)](https://github.com/SumaitaB/Stopwatch/assets/51522304/ee97c9fc-1333-486e-a244-d4350396e246)
